<?php 
	const BASE_URL = "https://iabanking.apps-adn.com";

	//Zona horaria
	date_default_timezone_set('America/Caracas');
	setlocale(LC_ALL, 'es_ES');


	//Datos de conexión a Base de Datos
	const DB_HOST = "localhost:3306";
	const DB_NAME = "banking_ia";
	const DB_USER = "banking_ia";
	const DB_PASSWORD = '9w8H&64ab';
	const DB_CHARSET = "utf8";

	const DB_HOST_BANKING = "localhost:3309";
	const DB_NAME_BANKING = "backing";
	const DB_USER_BANKING = "sistemas";
	const DB_PASSWORD_BANKING = 'adn';
	const DB_CHARSET_BANKING = "utf8";
?>