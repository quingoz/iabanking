    <script>
        const base_url = "<?= base_url(); ?>";
		const typeUser = "<?= $_SESSION['typeUser']; ?>";
    </script>
    
    <!-- Library Bundle Script -->
    <script src="<?= media() ?>/js/core/libs.min.js"></script>

    <!-- External Library Bundle Script -->
    <script src="<?= media() ?>/js/core/external.min.js"></script>

    <!-- Widgetchart Script -->
    <script src="<?= media() ?>/js/charts/widgetcharts.js"></script>

    <!-- mapchart Script -->
    <script src="<?= media() ?>/js/charts/vectore-chart.js"></script>
    <script src="<?= media() ?>/js/charts/dashboard.js"></script>

    <!-- fslightbox Script -->
    <script src="<?= media() ?>/js/plugins/fslightbox.js"></script>

    <!-- Settings Script -->
    <script src="<?= media() ?>/js/plugins/setting.js"></script>

    <!-- Slider-tab Script -->
    <script src="<?= media() ?>/js/plugins/slider-tabs.js"></script>

    <!-- Form Wizard Script -->
    <script src="<?= media() ?>/js/plugins/form-wizard.js"></script>

    <!-- AOS Animation Plugin-->
    <script src="<?= media() ?>/vendor/aos/dist/aos.js"></script>

    <!-- App Script -->
    <script src="<?= media() ?>/js/hope-ui.js" defer></script>

    <!-- SweetAlert 2 CDN -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script src="<?= media() ?>/js/plugins/select2.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/clipboard.js/2.0.6/clipboard.min.js"></script>

    <!-- DataTables -->
    <script type="text/javascript" src="<?= media();?>/js/plugins/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="<?= media();?>/js/plugins/dataTables.bootstrap.min.js"></script>

    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"> </script>
    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/plug-ins/1.10.25/api/sum().js"></script>

<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>