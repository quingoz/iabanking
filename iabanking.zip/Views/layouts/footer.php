<div class="footer-body">
                <ul class="left-panel list-inline mb-0 p-0">
                    <li class="list-inline-item text-primary">Desarrollado por ADN Software
                    </li>
                </ul>
                <div class="right-panel text-primary">
                    ©<script>
                    document.write(new Date().getFullYear())
                    </script> Banking AI
                </div>
            </div>